/* Publish by EComposer at 2023-07-12 18:46:44*/

                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-bxmmll9muap"]=  window.__ectimmers["ecom-bxmmll9muap"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"custom","lightbox":"no"};
                    const ID = 'ecom-bxmmll9muap';
                    document.querySelectorAll('.ecom-bxmmll9muap').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-x38d94pja5o"]=  window.__ectimmers["ecom-x38d94pja5o"] || {};
var e=this.$el;if(e&&this.isLive){var t=e.querySelectorAll(".element-social-link:not(.element-social-link__custom)");t.length&&t.forEach(function(n){var r=n.getAttribute("href")||"#",i=r.replace("{current-link}",location.href);n.setAttribute("href",i)})}

                    });
                    const settings = {};
                    const ID = 'ecom-x38d94pja5o';
                    document.querySelectorAll('.ecom-x38d94pja5o').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-kscmuvn93c"]=  window.__ectimmers["ecom-kscmuvn93c"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-kscmuvn93c"]["8w8k7nl82"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-kscmuvn93c';
                    document.querySelectorAll('.ecom-kscmuvn93c').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-t513hxt7ofq"]=  window.__ectimmers["ecom-t513hxt7ofq"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"none","lightbox":"no"};
                    const ID = 'ecom-t513hxt7ofq';
                    document.querySelectorAll('.ecom-t513hxt7ofq').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-zjttvp1biw9"]=  window.__ectimmers["ecom-zjttvp1biw9"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-zjttvp1biw9';
                    document.querySelectorAll('.ecom-zjttvp1biw9').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-70k40xtmea6"]=  window.__ectimmers["ecom-70k40xtmea6"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"custom","lightbox":"no"};
                    const ID = 'ecom-70k40xtmea6';
                    document.querySelectorAll('.ecom-70k40xtmea6').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-7j9cw92j3fe"]=  window.__ectimmers["ecom-7j9cw92j3fe"] || {};
var e=this.$el;if(e&&this.isLive){var t=e.querySelectorAll(".element-social-link:not(.element-social-link__custom)");t.length&&t.forEach(function(n){var r=n.getAttribute("href")||"#",i=r.replace("{current-link}",location.href);n.setAttribute("href",i)})}

                    });
                    const settings = {};
                    const ID = 'ecom-7j9cw92j3fe';
                    document.querySelectorAll('.ecom-7j9cw92j3fe').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-cgsn6xt0sfp"]=  window.__ectimmers["ecom-cgsn6xt0sfp"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-cgsn6xt0sfp"]["n69v9eq60"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-cgsn6xt0sfp';
                    document.querySelectorAll('.ecom-cgsn6xt0sfp').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-4eus1db74vq"]=  window.__ectimmers["ecom-4eus1db74vq"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-4eus1db74vq';
                    document.querySelectorAll('.ecom-4eus1db74vq').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-vkgtvw46jkf"]=  window.__ectimmers["ecom-vkgtvw46jkf"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"none","lightbox":"no"};
                    const ID = 'ecom-vkgtvw46jkf';
                    document.querySelectorAll('.ecom-vkgtvw46jkf').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-3wd1nbv2m7s"]=  window.__ectimmers["ecom-3wd1nbv2m7s"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-3wd1nbv2m7s';
                    document.querySelectorAll('.ecom-3wd1nbv2m7s').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-5ybhou2ifqp"]=  window.__ectimmers["ecom-5ybhou2ifqp"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-5ybhou2ifqp';
                    document.querySelectorAll('.ecom-5ybhou2ifqp').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-y3nx35oikml"]=  window.__ectimmers["ecom-y3nx35oikml"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-y3nx35oikml';
                    document.querySelectorAll('.ecom-y3nx35oikml').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-uy4xqi4pe1s"]=  window.__ectimmers["ecom-uy4xqi4pe1s"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-uy4xqi4pe1s';
                    document.querySelectorAll('.ecom-uy4xqi4pe1s').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-0zepj7bvv1m"]=  window.__ectimmers["ecom-0zepj7bvv1m"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-0zepj7bvv1m"]["ykx7flgw8"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-0zepj7bvv1m';
                    document.querySelectorAll('.ecom-0zepj7bvv1m').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-e7nam2r6if4"]=  window.__ectimmers["ecom-e7nam2r6if4"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-e7nam2r6if4"]["exo1li309"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-e7nam2r6if4';
                    document.querySelectorAll('.ecom-e7nam2r6if4').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-glh3hd5kujn"]=  window.__ectimmers["ecom-glh3hd5kujn"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-glh3hd5kujn';
                    document.querySelectorAll('.ecom-glh3hd5kujn').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-rnu82r4yqt8"]=  window.__ectimmers["ecom-rnu82r4yqt8"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-rnu82r4yqt8';
                    document.querySelectorAll('.ecom-rnu82r4yqt8').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-4rlr59fndb"]=  window.__ectimmers["ecom-4rlr59fndb"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-4rlr59fndb';
                    document.querySelectorAll('.ecom-4rlr59fndb').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-z7gwm5lldjc"]=  window.__ectimmers["ecom-z7gwm5lldjc"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-z7gwm5lldjc"]["uzgtsepvs"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-z7gwm5lldjc';
                    document.querySelectorAll('.ecom-z7gwm5lldjc').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-ds30w9qn5n"]=  window.__ectimmers["ecom-ds30w9qn5n"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-ds30w9qn5n"]["t35jnjvr7"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-ds30w9qn5n';
                    document.querySelectorAll('.ecom-ds30w9qn5n').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-t8n34chwjdn"]=  window.__ectimmers["ecom-t8n34chwjdn"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-t8n34chwjdn';
                    document.querySelectorAll('.ecom-t8n34chwjdn').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-tl6dixgviy8"]=  window.__ectimmers["ecom-tl6dixgviy8"] || {};
var g,u;const e=this.$el;if(!e)return;(g=this.settings.autoplay_progress)!=null;const i=e.querySelector(".ecom-autoplay-progress svg"),t=e.querySelector(".ecom-autoplay-progress span"),n=(u=this.settings.disable_lazy)!=null?u:!1;let a={};i&&t&&(a={autoplayTimeLeft(h,_,b){i.style.setProperty("--progress",1-b),t.textContent=`${Math.ceil(_/1e3)}s`}});const o=e.querySelector(".ecom-swiper-container"),s=JSON.parse(o.dataset.optionSwiper);s.pagination.el=e.querySelector(".ecom-swiper-pagination"),s.navigation.nextEl=e.querySelector(".ecom-swiper-button-next"),s.navigation.prevEl=e.querySelector(".ecom-swiper-button-prev"),s.pagination.renderBullet=(h,_)=>`<span class="${_}">
                          ${this.settings.items[h]&&this.settings.items[h].slider_pagination_image?`<img src="${this.settings.items[h].slider_pagination_image}">`:""}</span>`,a.init=function(){this.el.parentNode.classList.add("ecom-swiper-initialized-wrapper")};const l={allowTouchMove:this.isLive,on:a};if(this.isLive||(l.loop=!1),window.EComSwiper){let h=function(){const _=new window.EComSwiper(o,Object.assign(s,l));_.on("slideChange",function(){const b=_.activeIndex==0?_.slides.length-1:_.activeIndex-1,f=_.slides[b];if(f){const v=f.querySelectorAll(".ecom-animation.ecom-animated");v.length&&v.forEach(function(x){x.classList.remove("ecom-animated","animated"),x.classList.add("ecom-animated-slider")})}if(_.el){const v=_.slides[_.activeIndex];let x=null;v&&(x=v.querySelectorAll(".ecom-animation.ecom-animated-slider")),x&&x.length&&x.forEach(function(k){k.classList.add("ecom-animated")})}setTimeout(function(){_.pagination.render(),_.pagination.update()},50)})};var d;this.isLive&&window.innerWidth>768&&window.addEventListener("resize",function(){d&&clearTimeout(d),d=setTimeout(h,200)}),h()}let r=null;o.querySelectorAll("img").length&&o.querySelectorAll("img").forEach(function(h,_){n&&h.removeAttribute("loading"),h.addEventListener("load",function(){clearTimeout(r),r=setTimeout(()=>window.dispatchEvent(new window.Event("resize")),500)})})

                    });
                    const settings = {"items":[{"title":"Acrobatic Tricks","image":{"name":"The Complete Paragliding Sound Library | Acrobatic Tricks","ext":"jpg","id":"UvHG38Iw","value__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks_1c2711cc-b573-442a-b484-061620aebc66.jpg?v=1679575353","thumbnail__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks_1c2711cc-b573-442a-b484-061620aebc66.jpg?v=1679575353","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks_1c2711cc-b573-442a-b484-061620aebc66.jpg?v=1679575353","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks_1c2711cc-b573-442a-b484-061620aebc66.jpg?v=1679575353","alt":"The Complete Paragliding Sound Library | Acrobatic Tricks"},"hasElementRequestLiquid":false,"id":"ecom-6jgeuimjpoj","img_size":"cover","blocks":[]},{"title":"Straight & Thermal Flights","image":{"name":"The Complete Paragliding Sound Library | Straight & Thermal Flights","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights_bf0644e6-39ea-4977-b7b9-bdaf64a68b60.jpg?v=1679576423","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights_bf0644e6-39ea-4977-b7b9-bdaf64a68b60.jpg?v=1679576423","id":"Tk3GjNrW","value__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights_2e0121cf-f05c-4840-ac50-9c93fb9dd693.jpg?v=1679576437","thumbnail__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights_2e0121cf-f05c-4840-ac50-9c93fb9dd693.jpg?v=1679576437","alt":"The Complete Paragliding Sound Library | Straight & Thermal Flights"},"img_size":"cover","hasElementRequestLiquid":false,"id":"ecom-bzimzkopmg8","blocks":[]},{"title":"Take-Offs","image":{"name":"The Complete Paragliding Sound Library | Take-Offs","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX-TCPSL.ESHOP-GALLERY-03.221116-A_9f733feb-8092-4d88-a151-ebade5ec85cb.jpg?v=1675093791","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX-TCPSL.ESHOP-GALLERY-03.221116-A_9f733feb-8092-4d88-a151-ebade5ec85cb.jpg?v=1675093791","id":"twFzvLCQ","value__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Take-Offs_d9b87cff-3089-405a-a956-c7c178f2d58d.jpg?v=1679576602","thumbnail__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Take-Offs_d9b87cff-3089-405a-a956-c7c178f2d58d.jpg?v=1679576602","alt":"The Complete Paragliding Sound Library | Take-Offs"},"img_size":"cover","hasElementRequestLiquid":false,"id":"ecom-edtt6zu76ce","blocks":[]},{"title":"Wing & Gear Foley","image":{"name":"The Complete Paragliding Sound Library | Wing & Gear Foley","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX-TCPSL.ESHOP-GALLERY-04.221116-A_39cdee04-c5ed-40c4-8b10-d98f253c00d8.jpg?v=1675093812","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX-TCPSL.ESHOP-GALLERY-04.221116-A_39cdee04-c5ed-40c4-8b10-d98f253c00d8.jpg?v=1675093812","id":"Y3Gqfghz","value__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wing_Gear_Foley_56dcb096-8b42-40c6-81c6-0e6af357c2c4.jpg?v=1679577615","thumbnail__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wing_Gear_Foley_56dcb096-8b42-40c6-81c6-0e6af357c2c4.jpg?v=1679577615","alt":"The Complete Paragliding Sound Library | Wing & Gear Foley"},"img_size":"cover","hasElementRequestLiquid":false,"id":"ecom-rmxbiopfeq","blocks":[]},{"title":"Atmos & Crowds","image":{"name":"The Complete Paragliding Sound Library | Atmos & Crowds","ext":"jpg","id":"JJVmpysY","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX-TCPSL.ESHOP-GALLERY-05.221116-A_82663666-52eb-48c6-9f50-71f23f76720d.jpg?v=1675093832","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX-TCPSL.ESHOP-GALLERY-05.221116-A_82663666-52eb-48c6-9f50-71f23f76720d.jpg?v=1675093832","value__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Atmos_Crowds_3b50a229-e212-407c-b236-4c1bb1c2cd4b.jpg?v=1679577677","thumbnail__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Atmos_Crowds_3b50a229-e212-407c-b236-4c1bb1c2cd4b.jpg?v=1679577677","alt":"The Complete Paragliding Sound Library | Atmos & Crowds"},"hasElementRequestLiquid":false,"id":"ecom-fpi0clxgzm8","img_size":"cover","blocks":[]},{"title":"Wind Flows & Gusts","image":{"name":"The Complete Paragliding Sound Library | Wind Flows & Gusts","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX.TCPSL.ESHOP-GALLERY-06.221116-A_81e18cf3-0672-4e48-9ec8-e9794c802f3f.jpg?v=1675093857","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX.TCPSL.ESHOP-GALLERY-06.221116-A_81e18cf3-0672-4e48-9ec8-e9794c802f3f.jpg?v=1675093857","id":"F3cMaa4E","value__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wind_Flows_Gusts_31f255e4-6a90-452a-9ecb-6cc58553a9e9.jpg?v=1679577709","thumbnail__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wind_Flows_Gusts_31f255e4-6a90-452a-9ecb-6cc58553a9e9.jpg?v=1679577709","alt":"The Complete Paragliding Sound Library | Wind Flows & Gusts"},"img_size":"cover","hasElementRequestLiquid":false,"id":"ecom-u291q802s5k","blocks":[]},{"title":"Electronic Devices","image":{"name":"The Complete Paragliding Sound Library | Electronic Devices","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX.TCPSL.ESHOP-GALLERY-07.230128-C_f5b89a92-0f58-419e-9b3e-3e3226dfb5ae.jpg?v=1675093881","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/WFX.TCPSL.ESHOP-GALLERY-07.230128-C_f5b89a92-0f58-419e-9b3e-3e3226dfb5ae.jpg?v=1675093881","id":"lBmei9fp","value__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Electronic_Devices_c77883f4-0c3b-4eb1-bbf4-d1a0bcb98d4c.jpg?v=1679577735","thumbnail__mobile":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Electronic_Devices_c77883f4-0c3b-4eb1-bbf4-d1a0bcb98d4c.jpg?v=1679577735","alt":"The Complete Paragliding Sound Library | Electronic Devices"},"img_size":"cover","hasElementRequestLiquid":false,"id":"ecom-tjsjtbl8qd","blocks":[]}]};
                    const ID = 'ecom-tl6dixgviy8';
                    document.querySelectorAll('.ecom-tl6dixgviy8').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-e391d6z6236"]=  window.__ectimmers["ecom-e391d6z6236"] || {};
var g,u;const e=this.$el;if(!e)return;(g=this.settings.autoplay_progress)!=null;const i=e.querySelector(".ecom-autoplay-progress svg"),t=e.querySelector(".ecom-autoplay-progress span"),n=(u=this.settings.disable_lazy)!=null?u:!1;let a={};i&&t&&(a={autoplayTimeLeft(h,_,b){i.style.setProperty("--progress",1-b),t.textContent=`${Math.ceil(_/1e3)}s`}});const o=e.querySelector(".ecom-swiper-container"),s=JSON.parse(o.dataset.optionSwiper);s.pagination.el=e.querySelector(".ecom-swiper-pagination"),s.navigation.nextEl=e.querySelector(".ecom-swiper-button-next"),s.navigation.prevEl=e.querySelector(".ecom-swiper-button-prev"),s.pagination.renderBullet=(h,_)=>`<span class="${_}">
                          ${this.settings.items[h]&&this.settings.items[h].slider_pagination_image?`<img src="${this.settings.items[h].slider_pagination_image}">`:""}</span>`,a.init=function(){this.el.parentNode.classList.add("ecom-swiper-initialized-wrapper")};const l={allowTouchMove:this.isLive,on:a};if(this.isLive||(l.loop=!1),window.EComSwiper){let h=function(){const _=new window.EComSwiper(o,Object.assign(s,l));_.on("slideChange",function(){const b=_.activeIndex==0?_.slides.length-1:_.activeIndex-1,f=_.slides[b];if(f){const v=f.querySelectorAll(".ecom-animation.ecom-animated");v.length&&v.forEach(function(x){x.classList.remove("ecom-animated","animated"),x.classList.add("ecom-animated-slider")})}if(_.el){const v=_.slides[_.activeIndex];let x=null;v&&(x=v.querySelectorAll(".ecom-animation.ecom-animated-slider")),x&&x.length&&x.forEach(function(k){k.classList.add("ecom-animated")})}setTimeout(function(){_.pagination.render(),_.pagination.update()},50)})};var d;this.isLive&&window.innerWidth>768&&window.addEventListener("resize",function(){d&&clearTimeout(d),d=setTimeout(h,200)}),h()}let r=null;o.querySelectorAll("img").length&&o.querySelectorAll("img").forEach(function(h,_){n&&h.removeAttribute("loading"),h.addEventListener("load",function(){clearTimeout(r),r=setTimeout(()=>window.dispatchEvent(new window.Event("resize")),500)})})

                    });
                    const settings = {"items":[{"image":{"name":"The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks.jpg?v=1679431171","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks.jpg?v=1679431171","id":"EHj3D84j","alt":"The_Complete_Paragliding_Sound_Library_Acrobatic_Tricks"},"img_size":"cover","title":"Acro Tricks","hasElementRequestLiquid":false,"id":"ecom-xtviz7kpry","img_position":"center-center","blocks":[]},{"image":{"name":"The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights.jpg?v=1679431216","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights.jpg?v=1679431216","id":"8M4W1WDw","alt":"The_Complete_Paragliding_Sound_Library_Straight_Thermal_Flights"},"img_size":"cover","title":"Straight & Thermal Flights","hasElementRequestLiquid":false,"id":"ecom-ur8is6yhf3","img_position":"center-center","overlay":false,"blocks":[]},{"image":{"name":"The_Complete_Paragliding_Sound_Library_Take-Offs","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Take-Offs.jpg?v=1679431239","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Take-Offs.jpg?v=1679431239","id":"3swsr9c3","alt":"The_Complete_Paragliding_Sound_Library_Take-Offs"},"img_size":"cover","title":"Take-offs","hasElementRequestLiquid":false,"id":"ecom-y069yky2xch","blocks":[]},{"image":{"name":"The_Complete_Paragliding_Sound_Library_Wing_Gear_Foley","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wing_Gear_Foley.jpg?v=1679431301","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wing_Gear_Foley.jpg?v=1679431301","id":"FgwMj9xN","alt":"The_Complete_Paragliding_Sound_Library_Wing_Gear_Foley"},"img_size":"cover","title":"Wing & Gear Foley","hasElementRequestLiquid":false,"id":"ecom-lfu0fq658qt","blocks":[]},{"image":{"name":"The_Complete_Paragliding_Sound_Library_Atmos_Crowds","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Atmos_Crowds.jpg?v=1679431335","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Atmos_Crowds.jpg?v=1679431335","id":"vsp4HPeF","alt":"The_Complete_Paragliding_Sound_Library_Atmos_Crowds"},"img_size":"cover","title":"Atmos & Crowds","hasElementRequestLiquid":false,"id":"ecom-ycsh69en3h","blocks":[]},{"image":{"name":"The_Complete_Paragliding_Sound_Library_Wind_Flows_Gusts","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wind_Flows_Gusts.jpg?v=1679431369","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Wind_Flows_Gusts.jpg?v=1679431369","id":"nygIXheK","alt":"The_Complete_Paragliding_Sound_Library_Wind_Flows_Gusts"},"img_size":"cover","title":"WInds & Gusts","hasElementRequestLiquid":false,"id":"ecom-fgiix00u4xv","blocks":[]},{"image":{"name":"The_Complete_Paragliding_Sound_Library_Electronic_Devices","ext":"jpg","value":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Electronic_Devices.jpg?v=1679431388","thumbnail":"https://cdn.shopify.com/s/files/1/0672/6221/8549/files/The_Complete_Paragliding_Sound_Library_Electronic_Devices.jpg?v=1679431388","id":"vLbUmhIl","alt":"The_Complete_Paragliding_Sound_Library_Electronic_Devices"},"hasElementRequestLiquid":false,"id":"ecom-39fv74ntf3o","img_size":"cover","title":"Electronic Devices","blocks":[]}]};
                    const ID = 'ecom-e391d6z6236';
                    document.querySelectorAll('.ecom-e391d6z6236').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-748g1qb4dkv"]=  window.__ectimmers["ecom-748g1qb4dkv"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"none","lightbox":"no"};
                    const ID = 'ecom-748g1qb4dkv';
                    document.querySelectorAll('.ecom-748g1qb4dkv').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-ce69xk9rntk"]=  window.__ectimmers["ecom-ce69xk9rntk"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-ce69xk9rntk';
                    document.querySelectorAll('.ecom-ce69xk9rntk').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-n2603g2by6"]=  window.__ectimmers["ecom-n2603g2by6"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-n2603g2by6';
                    document.querySelectorAll('.ecom-n2603g2by6').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-wkb2u4x5n4t"]=  window.__ectimmers["ecom-wkb2u4x5n4t"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-wkb2u4x5n4t';
                    document.querySelectorAll('.ecom-wkb2u4x5n4t').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-6ro9lhpck2i"]=  window.__ectimmers["ecom-6ro9lhpck2i"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"none","lightbox":"no"};
                    const ID = 'ecom-6ro9lhpck2i';
                    document.querySelectorAll('.ecom-6ro9lhpck2i').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-pqm26d2fgr"]=  window.__ectimmers["ecom-pqm26d2fgr"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-pqm26d2fgr"]["efyxkc1od"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-pqm26d2fgr';
                    document.querySelectorAll('.ecom-pqm26d2fgr').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-bgv2qve4smn"]=  window.__ectimmers["ecom-bgv2qve4smn"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-bgv2qve4smn"]["q1k9udzu"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-bgv2qve4smn';
                    document.querySelectorAll('.ecom-bgv2qve4smn').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-3kngqp5oyev"]=  window.__ectimmers["ecom-3kngqp5oyev"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"none","lightbox":"no"};
                    const ID = 'ecom-3kngqp5oyev';
                    document.querySelectorAll('.ecom-3kngqp5oyev').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-9w77701q6u"]=  window.__ectimmers["ecom-9w77701q6u"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-9w77701q6u';
                    document.querySelectorAll('.ecom-9w77701q6u').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-o1adk3hwgp"]=  window.__ectimmers["ecom-o1adk3hwgp"] || {};
if(!this.$el)return;const e=this.$el,i=e.querySelector(".ecom-text_view-more-btn"),t=e.querySelector(".ecom-text_view-less-btn"),n=e.querySelector(".text-content.ecom-html");!n||(i&&i.addEventListener("click",()=>{n.classList.remove("ecom-text--is-mark"),n.style.maxHeight="",i.style.display="none",t.style.display=""}),t&&t.addEventListener("click",()=>{n.classList.add("ecom-text--is-mark"),n.style.maxHeight="var(--ecom-text-height)",t.style.display="none",i.style.display=""}))

                    });
                    const settings = {};
                    const ID = 'ecom-o1adk3hwgp';
                    document.querySelectorAll('.ecom-o1adk3hwgp').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-14rn76t4n7y"]=  window.__ectimmers["ecom-14rn76t4n7y"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"none","lightbox":"no"};
                    const ID = 'ecom-14rn76t4n7y';
                    document.querySelectorAll('.ecom-14rn76t4n7y').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-kg40yiii4g"]=  window.__ectimmers["ecom-kg40yiii4g"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-kg40yiii4g"]["z6gzyv081"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-kg40yiii4g';
                    document.querySelectorAll('.ecom-kg40yiii4g').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-rr7ttqi48qf"]=  window.__ectimmers["ecom-rr7ttqi48qf"] || {};
if(!this.$el)return!1;const e=this.$el;this.settings.animation&&function(t){if(!e)return;const n=e.querySelector(".ecom__element--button");if(!n)return;let a=parseInt(t.settings.animation_loop_time)*1e3||6e3,o=1e3;window.__ectimmers["ecom-rr7ttqi48qf"]["u9oqs9o78"] = setInterval(function(){n.classList.add("animated"),setTimeout(function(){n.classList.remove("animated")},o)},a)}(this);var i=e.querySelector(".ecom__element--button");this.isLive&&i&&i.dataset.ecTrackingId&&i.addEventListener("click",function(t){if(window.Shopify.analytics){t.preventDefault();let n=document.createElement("div");document.body.appendChild(n),n.click(),Shopify.analytics.publish("ec_custom_events",{button_id:i.id,tracking_id:i.dataset.ecTrackingId}),i.cloneNode(!0).click()}},{once:!0})

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-rr7ttqi48qf';
                    document.querySelectorAll('.ecom-rr7ttqi48qf').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-11er4lp4v6lg"]=  window.__ectimmers["ecom-11er4lp4v6lg"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"custom","lightbox":"no"};
                    const ID = 'ecom-11er4lp4v6lg';
                    document.querySelectorAll('.ecom-11er4lp4v6lg').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-xnghv7gfbob"]=  window.__ectimmers["ecom-xnghv7gfbob"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"custom","lightbox":"no"};
                    const ID = 'ecom-xnghv7gfbob';
                    document.querySelectorAll('.ecom-xnghv7gfbob').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-3egu192gsqw"]=  window.__ectimmers["ecom-3egu192gsqw"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"custom","lightbox":"no"};
                    const ID = 'ecom-3egu192gsqw';
                    document.querySelectorAll('.ecom-3egu192gsqw').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-r9kpepkwv7r"]=  window.__ectimmers["ecom-r9kpepkwv7r"] || {};
if(this.settings.link==="lightbox"&&this.settings.lightbox==="yes"&&window.EComModal&&this.$el){var e=this.$el.querySelector("[ecom-modal]");new window.EComModal(e,{cssClass:["ecom-container-lightbox-"+this.id]})}

                    });
                    const settings = {"link":"custom","lightbox":"no"};
                    const ID = 'ecom-r9kpepkwv7r';
                    document.querySelectorAll('.ecom-r9kpepkwv7r').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-g9hvyar7ke4"]=  window.__ectimmers["ecom-g9hvyar7ke4"] || {};
if(!this.$el)return!1;const e=this.$el,i=e.closest(".ecom-product-form--single");if(!i)return!1;const t=i.querySelector('[name="id"]');if(!this.isLive)i&&t&&t.dispatchEvent(new window.Event("ecomUpdate"));else{const a=e.querySelector(".ecom-product-single__add-to-cart--submit"),o=e.closest("form");if(!o)return;if(!o.querySelector("select[name=id]")){let s=null;const l=o.dataset.product_id;if(!l)return;const d=o.querySelector("[id^=product-json-"+l+"]");if(!d)return;try{s=JSON.parse(d.innerHTML)}catch(g){return}let r=s.variants[0];if(r){const g=a.querySelector(".ecom-add-to-cart-text");if(!g)return;r.available==!1?(a.setAttribute("disabled","disabled"),g.innerText=a.dataset.textOutstock):r.inventory_quantity<=0&&r.inventory_policy=="continue"&&(g.innerText=a.dataset.textPreOrder)}}if(!t&&a&&a.dataset.variant_id){const s=document.createElement("input");s.type="hidden",s.value=a.dataset.variant_id,e.appendChild(s)}}const n=function(a){if(!e)return;const o=e.querySelector(".ecom-product-single__add-to-cart--submit");if(!o)return;let s=parseInt(a.settings.animation_loop_time)*1e3||6e3,l=1e3;window.__ectimmers["ecom-g9hvyar7ke4"]["sfppj50r7"] = setInterval(function(){o.classList.add("animated"),setTimeout(function(){o.classList.remove("animated")},l)},s)};this.settings.animation&&n(this)

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-g9hvyar7ke4';
                    document.querySelectorAll('.ecom-g9hvyar7ke4').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                (function(){
                    const Func = (function() {
                        'use strict';
window.__ectimmers = window.__ectimmers ||{};window.__ectimmers["ecom-835s34ap3aw"]=  window.__ectimmers["ecom-835s34ap3aw"] || {};
if(!this.$el)return!1;const e=this.$el,i=e.closest(".ecom-product-form--single");if(!i)return!1;const t=i.querySelector('[name="id"]');if(!this.isLive)i&&t&&t.dispatchEvent(new window.Event("ecomUpdate"));else{const a=e.querySelector(".ecom-product-single__add-to-cart--submit"),o=e.closest("form");if(!o)return;if(!o.querySelector("select[name=id]")){let s=null;const l=o.dataset.product_id;if(!l)return;const d=o.querySelector("[id^=product-json-"+l+"]");if(!d)return;try{s=JSON.parse(d.innerHTML)}catch(g){return}let r=s.variants[0];if(r){const g=a.querySelector(".ecom-add-to-cart-text");if(!g)return;r.available==!1?(a.setAttribute("disabled","disabled"),g.innerText=a.dataset.textOutstock):r.inventory_quantity<=0&&r.inventory_policy=="continue"&&(g.innerText=a.dataset.textPreOrder)}}if(!t&&a&&a.dataset.variant_id){const s=document.createElement("input");s.type="hidden",s.value=a.dataset.variant_id,e.appendChild(s)}}const n=function(a){if(!e)return;const o=e.querySelector(".ecom-product-single__add-to-cart--submit");if(!o)return;let s=parseInt(a.settings.animation_loop_time)*1e3||6e3,l=1e3;window.__ectimmers["ecom-835s34ap3aw"]["mjd5dqtlo"] = setInterval(function(){o.classList.add("animated"),setTimeout(function(){o.classList.remove("animated")},l)},s)};this.settings.animation&&n(this)

                    });
                    const settings = {"animation":false};
                    const ID = 'ecom-835s34ap3aw';
                    document.querySelectorAll('.ecom-835s34ap3aw').forEach(function(el){
                        Func.call({$el: el, settings, id:ID,isLive: true});
                    });
                })();
            
                if(window.location.search.indexOf("ecom-token=") < 0)
                {
                    document.querySelector(".ecom-builder").innerHTML = '<h3 style="width:100%;display:block;text-align:center">This template for preview purposes only</h3>';
                    document.querySelector("body").style.opacity= "0.7";
                }
            